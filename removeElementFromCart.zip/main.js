import './style.css'
import products from "./api/product.json"
import { showProductContainer } from './template';


showProductContainer(products);

// products.forEach((prodElem)=>{

// })
